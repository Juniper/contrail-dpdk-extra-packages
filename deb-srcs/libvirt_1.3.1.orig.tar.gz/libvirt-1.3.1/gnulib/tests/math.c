#include <config.h>
#define _GL_MATH_INLINE _GL_EXTERN_INLINE
#include "math.h"
typedef int dummy;
