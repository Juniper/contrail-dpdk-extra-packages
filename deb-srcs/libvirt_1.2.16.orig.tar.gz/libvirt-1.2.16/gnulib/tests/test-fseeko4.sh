#!/bin/sh

./test-fseeko4${EXEEXT} "$srcdir/test-fseeko4.sh" || exit 1

exit 0
